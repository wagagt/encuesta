<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $requisitosPuesto->id !!}</p>
</div>

<!-- Requerido Field -->
<div class="form-group">
    {!! Form::label('requerido', 'Requerido:') !!}
    <p>{!! $requisitosPuesto->requerido !!}</p>
</div>

<!-- Tipo Field -->
<div class="form-group">
    {!! Form::label('tipo', 'Tipo:') !!}
    <p>{!! $requisitosPuesto->tipo !!}</p>
</div>

<!-- Enunciado Field -->
<div class="form-group">
    {!! Form::label('enunciado', 'Enunciado:') !!}
    <p>{!! $requisitosPuesto->enunciado !!}</p>
</div>

<!-- Rango Respuestas Field -->
<div class="form-group">
    {!! Form::label('rango_respuestas', 'Rango Respuestas:') !!}
    <p>{!! $requisitosPuesto->rango_respuestas !!}</p>
</div>

<!-- Respuesta Field -->
<div class="form-group">
    {!! Form::label('respuesta', 'Respuesta:') !!}
    <p>{!! $requisitosPuesto->respuesta !!}</p>
</div>

<!-- Notas Field -->
<div class="form-group">
    {!! Form::label('notas', 'Notas:') !!}
    <p>{!! $requisitosPuesto->notas !!}</p>
</div>

