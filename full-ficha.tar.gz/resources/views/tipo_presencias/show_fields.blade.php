<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $tipoPresencia->id !!}</p>
</div>

<!-- Paso Id Field -->
<div class="form-group">
    {!! Form::label('paso_id', 'Paso Id:') !!}
    <p>{!! $tipoPresencia->paso_id !!}</p>
</div>

<!-- Descripcion Field -->
<div class="form-group">
    {!! Form::label('descripcion', 'Descripcion:') !!}
    <p>{!! $tipoPresencia->descripcion !!}</p>
</div>

<!-- Tipo Field -->
<div class="form-group">
    {!! Form::label('tipo', 'Tipo:') !!}
    <p>{!! $tipoPresencia->tipo !!}</p>
</div>

<!-- Minimo Field -->
<div class="form-group">
    {!! Form::label('minimo', 'Minimo:') !!}
    <p>{!! $tipoPresencia->minimo !!}</p>
</div>

<!-- Maximo Field -->
<div class="form-group">
    {!! Form::label('maximo', 'Maximo:') !!}
    <p>{!! $tipoPresencia->maximo !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $tipoPresencia->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $tipoPresencia->updated_at !!}</p>
</div>

