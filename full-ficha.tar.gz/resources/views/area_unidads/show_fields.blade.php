<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $areaUnidad->id !!}</p>
</div>

<!-- Area Id Field -->
<div class="form-group">
    {!! Form::label('area_id', 'Area Id:') !!}
    <p>{!! $areaUnidad->area_id !!}</p>
</div>

<!-- Unidade Id Field -->
<div class="form-group">
    {!! Form::label('unidade_id', 'Unidade Id:') !!}
    <p>{!! $areaUnidad->unidade_id !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $areaUnidad->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $areaUnidad->updated_at !!}</p>
</div>

