<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $horariosInstitucion->id !!}</p>
</div>

<!-- Institucione Id Field -->
<div class="form-group">
    {!! Form::label('institucione_id', 'Institucione Id:') !!}
    <p>{!! $horariosInstitucion->institucione_id !!}</p>
</div>

<!-- Dia Field -->
<div class="form-group">
    {!! Form::label('dia', 'Dia:') !!}
    <p>{!! $horariosInstitucion->dia !!}</p>
</div>

<!-- Entrada Field -->
<div class="form-group">
    {!! Form::label('entrada', 'Entrada:') !!}
    <p>{!! $horariosInstitucion->entrada !!}</p>
</div>

<!-- Salida Field -->
<div class="form-group">
    {!! Form::label('salida', 'Salida:') !!}
    <p>{!! $horariosInstitucion->salida !!}</p>
</div>

<!-- Medio Dia Cierra Field -->
<div class="form-group">
    {!! Form::label('medio_dia_cierra', 'Medio Dia Cierra:') !!}
    <p>{!! $horariosInstitucion->medio_dia_cierra !!}</p>
</div>

<!-- Medio Dia Abre Field -->
<div class="form-group">
    {!! Form::label('medio_dia_abre', 'Medio Dia Abre:') !!}
    <p>{!! $horariosInstitucion->medio_dia_abre !!}</p>
</div>

<!-- Notas Field -->
<div class="form-group">
    {!! Form::label('notas', 'Notas:') !!}
    <p>{!! $horariosInstitucion->notas !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $horariosInstitucion->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $horariosInstitucion->updated_at !!}</p>
</div>

