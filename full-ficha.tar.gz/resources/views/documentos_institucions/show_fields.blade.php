<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $documentosInstitucion->id !!}</p>
</div>

<!-- Institucione Id Field -->
<div class="form-group">
    {!! Form::label('institucione_id', 'Institucione Id:') !!}
    <p>{!! $documentosInstitucion->institucione_id !!}</p>
</div>

<!-- Tipo Documento Field -->
<div class="form-group">
    {!! Form::label('tipo_documento', 'Tipo Documento:') !!}
    <p>{!! $documentosInstitucion->tipo_documento !!}</p>
</div>

<!-- Ubicacion Field -->
<div class="form-group">
    {!! Form::label('ubicacion', 'Ubicacion:') !!}
    <p>{!! $documentosInstitucion->ubicacion !!}</p>
</div>

<!-- Notas Field -->
<div class="form-group">
    {!! Form::label('notas', 'Notas:') !!}
    <p>{!! $documentosInstitucion->notas !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $documentosInstitucion->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $documentosInstitucion->updated_at !!}</p>
</div>

