<div class="form-group col-md-12">
    <table class="table table-responsive table-bordered" id="empresas-table">
        <thead>
        <th>Día</th>
        <th>DE</th>
        <th>A</th>

        </thead>
        <tbody>

            <tr>
                <td>lunes</td>
                <td>{!! Form::date('medio_dia_cierra', null,['form-control']) !!}</td>
                <td>{!! Form::date('medio_dia_abre', null,['form-control']) !!} </td>

            </tr>
            <tr>
                <td>Martes</td>
                <td>{!! Form::date('medio_dia_cierra', null,['form-control']) !!}</td>
                <td>{!! Form::date('medio_dia_abre', null,['form-control']) !!} </td>

            </tr>
            <tr>
                <td>Miércoles</td>
                <td>{!! Form::date('medio_dia_cierra', null,['form-control']) !!}</td>
                <td>{!! Form::date('medio_dia_abre', null,['form-control']) !!} </td>

            </tr>
            <tr>
                <td>lunes</td>
                <td>{!! Form::date('medio_dia_cierra', null,['form-control']) !!}</td>
                <td>{!! Form::date('medio_dia_abre', null,['form-control']) !!} </td>

            </tr>
            <tr>
                <td>lunes</td>
                <td>{!! Form::date('medio_dia_cierra', null,['form-control']) !!}</td>
                <td>{!! Form::date('medio_dia_abre', null,['form-control']) !!} </td>

            </tr>
            <tr>
                <td>lunes</td>
                <td>{!! Form::date('medio_dia_cierra', null,['form-control']) !!}</td>
                <td>{!! Form::date('medio_dia_abre', null,['form-control']) !!} </td>

            </tr>
            <tr>
                <td>lunes</td>
                <td>{!! Form::date('medio_dia_cierra', null,['form-control']) !!}</td>
                <td>{!! Form::date('medio_dia_abre', null,['form-control']) !!} </td>

            </tr>


        </tbody>
    </table>

</div>




