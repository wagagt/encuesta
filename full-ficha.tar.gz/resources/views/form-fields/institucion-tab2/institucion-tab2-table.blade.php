<div class="col-md-12">
    <table class="table table-striped table-bordered  jambo_table" id="empresas-table">
        <thead>
        <th class="text-center">UNIDAD</th>
        <th class="text-center">DIRECCION</th>
        <th class="text-center">TELEFONO</th>
        <th class="text-center">ACCIONES</th>
        </thead>
        <tbody>

        <tr>
            <td class="text-center">Unidad Uno</td>
            <td class="text-center">direccion</td>
            <td class="text-center">telefono</td>
            <td class="text-center"><a href="#" class="btn btn-info" style="font-size: 10px;"><i class="fa fa-camera"></i></a>
                <a href="#" class="btn btn-info" style="font-size: 10px;"><i class="fa fa-trash"></i></a>
            </td>
        </tr>
        <tr>
            <td class="text-center">Unidad Uno</td>
            <td class="text-center">direccion</td>
            <td class="text-center">telefono</td>
            <td class="text-center"><a href="#" class="btn btn-info" style="font-size: 10px;"><i class="fa fa-camera"></i></a>
                <a href="#" class="btn btn-info" style="font-size: 10px;"><i class="fa fa-trash"></i></a>
            </td>
        </tr>
        <tr>
            <td class="text-center">Unidad Uno</td>
            <td class="text-center">direccion</td>
            <td class="text-center">telefono</td>
            <td class="text-center"><a href="#" class="btn btn-info" style="font-size: 10px;"><i class="fa fa-camera"></i></a>
                <a href="#" class="btn btn-info" style="font-size: 10px;"><i class="fa fa-trash"></i></a>
            </td>
        </tr>




        </tbody>
    </table>

</div>




