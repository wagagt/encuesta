<!DOCTYPE html>
<html>

@include('layouts.partials.htmlheader')

@yield('main-content')

</html>