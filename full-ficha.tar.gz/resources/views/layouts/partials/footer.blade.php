<!-- Main Footer -->
<footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
        <a href="https://github.com/acacha/adminlte-laravel"></a><b>Ficha Electrónica</b></a>. {{ trans('adminlte_lang::message.descriptionpackage') }}
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2017 <a href="http://acacha.org">creditos.org</a>.</strong> {{ trans('adminlte_lang::message.createdby') }} <a href="http://acacha.org/sergitur">Sergi Tur Badenas</a>. {{ trans('adminlte_lang::message.seecode') }} <a href="https://github.com/acacha/adminlte-laravel">Github</a>
</footer>