<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $metodoPago->id !!}</p>
</div>

<!-- Paso Id Field -->
<div class="form-group">
    {!! Form::label('paso_id', 'Paso Id:') !!}
    <p>{!! $metodoPago->paso_id !!}</p>
</div>

<!-- Nombre Field -->
<div class="form-group">
    {!! Form::label('nombre', 'Nombre:') !!}
    <p>{!! $metodoPago->nombre !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $metodoPago->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $metodoPago->updated_at !!}</p>
</div>

