<!-- Bootstrap -->
<link href="{{asset('ui/uix/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet">
<!-- Font Awesome -->
<link href="{{asset('ui/uix/font-awesome/css/font-awesome.min.css')}}" rel="stylesheet">
<!-- Animate.css -->
<link href="https://colorlib.com/polygon/gentelella/css/animate.min.css" rel="stylesheet">

<!-- Custom Theme Style -->
<link href="{{asset('ui/uix/build/css/custom.min.css')}}" rel="stylesheet">
<![endif]-->
@yield('css')