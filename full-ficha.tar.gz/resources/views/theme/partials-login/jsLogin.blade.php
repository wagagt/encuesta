<!-- jQuery 2.2.3 -->
<script src="{{asset('ui/plugins/jQuery/jquery-2.2.3.min.js')}}"></script>
<!-- Bootstrap 3.3.6 -->
<script src="{{asset('ui/bootstrap/js/bootstrap.min.js')}}"></script>
<!-- iCheck -->
<script src="{{asset('ui/plugins/iCheck/icheck.min.js')}}"></script>


@yield('js')