<div class="pull-right">
    Todos los derechos reservados &reg; {{date('Y')}}
</div>
<div class="clearfix"></div>
