<div class="profile">
    <div class="profile_pic">
        <img src="{{asset('ui/images/imgs-uix/img.jpg')}}" alt="Perfil imagen" class="img-circle profile_img">
    </div>
    <div class="profile_info">
        <span>Bienvenido,</span>
        <h2>Axel Sarceño</h2>
    </div>
</div>