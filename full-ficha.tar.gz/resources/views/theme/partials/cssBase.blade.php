<!-- Bootstrap -->
<link href="{{ asset('ui/uix/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet">
<!-- Font Awesome -->
<link href="{{ asset('ui/uix/font-awesome/css/font-awesome.min.css') }}" rel="stylesheet">
<!-- iCheck -->
<link href="{{ asset('ui/uix/iCheck/skins/flat/green.css') }}" rel="stylesheet">
<!-- bootstrap-wysiwyg -->
<link href="{{ asset('ui/uix/google-code-prettify/bin/prettify.min.css') }}" rel="stylesheet">
<!-- Select2 -->
<link href="{{ asset('ui/uix/select2/dist/css/select2.min.css') }}" rel="stylesheet">
<!-- Switchery -->
<link href="{{ asset('ui/uix/switchery/dist/switchery.min.css') }}" rel="stylesheet">
<!-- starrr -->
<link href="{{ asset('ui/uix/starrr/dist/starrr.css') }}" rel="stylesheet">

<!-- Custom Theme Style -->
<link href="{{ asset('ui/uix/build/css/custom.min.css') }}" rel="stylesheet">