<!-- jQuery -->
<script src="{{ asset('ui/uix/jquery/dist/jquery.min.js') }}"></script>
<!-- Bootstrap -->
<script src="{{ asset('ui/uix/bootstrap/js/bootstrap.min.js') }}"></script>
<!-- FastClick -->
<script src="{{ asset('ui/uix/fastclick/lib/fastclick.js') }}"></script>
<!-- NProgress -->
<script src="{{ asset('ui/uix/nprogress/nprogress.js') }}"></script>
<!-- bootstrap-progressbar -->
<script src="{{ asset('ui/uix/bootstrap-progressbar/bootstrap-progressbar.min.js') }}"></script>
<!-- iCheck -->
<script src="{{ asset('ui/uix/iCheck/icheck.min.js') }}"></script>
<!-- bootstrap-daterangepicker -->
<script src="{{ asset('ui/uix/personal-plug/js/moment/moment.min.js') }}"></script>
<script src="{{ asset('ui/uix/personal-plug/js/datepicker/daterangepicker.js') }}"></script>
<!-- bootstrap-wysiwyg -->
<script src="{{ asset('ui/uix/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js') }}"></script>
<script src="{{ asset('ui/uix/jquery.hotkeys/jquery.hotkeys.js') }}"></script>
<script src="{{ asset('ui/uix/google-code-prettify/src/prettify.js') }}"></script>
<!-- jQuery Tags Input -->
<script src="{{ asset('ui/uix/jquery.tagsinput/src/jquery.tagsinput.js') }}"></script>
<!-- Switchery -->
<script src="{{ asset('ui/uix/switchery/dist/switchery.min.js') }}"></script>
<!-- Select2 -->
<script src="{{ asset('ui/uix/select2/dist/js/select2.full.min.js') }}"></script>
<!-- Parsley -->
<script src="{{ asset('ui/uix/parsleyjs/dist/parsley.min.js') }}"></script>
<!-- Autosize -->
<script src="{{ asset('ui/uix/autosize/autosize.min.js') }}"></script>
<!-- jQuery autocomplete -->
<script src="{{ asset('ui/uix/devbridge-autocomplete/dist/jquery.autocomplete.min.js') }}"></script>
<!-- starrr -->
<script src="{{ asset('ui/uix/starrr/dist/starrr.js') }}"></script>

<script src="{{ asset('ui/uix/jQuery-Smart-Wizard/js/jquery.smartWizard.js ')}}"></script>

<!-- Custom Theme Scripts -->
<script src="{{ asset('ui/uix/build/js/custom.min.js') }}"></script>

@yield('js')