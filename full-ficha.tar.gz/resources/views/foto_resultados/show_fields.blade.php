<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $fotoResultado->id !!}</p>
</div>

<!-- Resultado Id Field -->
<div class="form-group">
    {!! Form::label('resultado_id', 'Resultado Id:') !!}
    <p>{!! $fotoResultado->resultado_id !!}</p>
</div>

<!-- Descripcion Field -->
<div class="form-group">
    {!! Form::label('descripcion', 'Descripcion:') !!}
    <p>{!! $fotoResultado->descripcion !!}</p>
</div>

<!-- Especifique Field -->
<div class="form-group">
    {!! Form::label('especifique', 'Especifique:') !!}
    <p>{!! $fotoResultado->especifique !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $fotoResultado->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $fotoResultado->updated_at !!}</p>
</div>

