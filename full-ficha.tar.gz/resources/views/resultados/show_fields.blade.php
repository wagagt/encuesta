<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $resultado->id !!}</p>
</div>

<!-- Tipo Resultado Id Field -->
<div class="form-group">
    {!! Form::label('tipo_resultado_id', 'Tipo Resultado Id:') !!}
    <p>{!! $resultado->tipo_resultado_id !!}</p>
</div>

<!-- Paso Id Field -->
<div class="form-group">
    {!! Form::label('paso_id', 'Paso Id:') !!}
    <p>{!! $resultado->paso_id !!}</p>
</div>

<!-- Nombre Field -->
<div class="form-group">
    {!! Form::label('nombre', 'Nombre:') !!}
    <p>{!! $resultado->nombre !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $resultado->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $resultado->updated_at !!}</p>
</div>

